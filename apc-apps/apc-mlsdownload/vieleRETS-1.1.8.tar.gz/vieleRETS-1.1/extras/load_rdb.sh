#! /bin/sh
#mysql -ujoe -hlocalhost -pschmoe <viele_create.mysql
mysql -ujoe -hlocalhost -pschmoe viele<viele_define.mysql
