#!/bin/sh
#
# VieleRETS cleanup script for MAC OSX, Unix and Linux
#

rm -rf targets 

rm -rf extracts 

rm -rf sources 
 
rm -rf cache 
 
rm -rf metadata 

rm -rf batch_control_files 

cp ../vieleRETS-work/DEMO setup/templates/default_source 

rm -rf logs 

