#!/bin/sh
#
# VieleRETS upgrade to 1.1.6 script for MAC OSX, Unix and Linux
#

mkdir logs 
chmod 777 logs 

