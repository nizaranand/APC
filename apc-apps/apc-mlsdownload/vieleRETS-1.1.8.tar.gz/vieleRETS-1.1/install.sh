#!/bin/sh
#
# VieleRETS installation script for MAC OSX, Unix and Linux
#

mkdir targets
chmod 777 targets

mkdir extracts
chmod 777 extracts

mkdir sources 
chmod 777 sources
 
mkdir cache 
chmod 777 cache 
 
mkdir metadata 
chmod 777 metadata 

mkdir batch_control_files 
chmod 777 batch_control_files 

mkdir logs 
chmod 777 logs 
 
